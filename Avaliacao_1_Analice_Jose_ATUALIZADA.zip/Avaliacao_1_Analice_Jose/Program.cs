﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Runtime.InteropServices;

namespace Avaliação1
{
    internal class Program
    {      
        static void Main(string[] args)
        {            
            Poligonal poligonal = new Poligonal();
            poligonal.Painel();
            poligonal.Opcoes();

            
        }
    }
}
