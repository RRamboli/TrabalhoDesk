﻿using Avaliação1;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Avaliação1
{
    internal class Poligonal
    {
        private int azGraus;
        private int azMinutos;
        private int azSegundos;
        private double calculoPerimetro = 90.76;
        private string descricao;
        List<Estacao> estacoes = new List<Estacao>();
        public Estacao estacaoAnt = new();


        public Poligonal()
        {
            Descricao = "FAZENDA RIO VERDE";

            Estacao estacaoFirst = new Estacao();
            estacaoFirst.numero = 1;
            estacaoFirst.Graus = 60;
            estacaoFirst.Minutos = 30;
            estacaoFirst.Segundos = 20;
            estacaoFirst.deflexao = 'E';
            estacaoFirst.distancia = 90.76;
            
            estacoes.Add(estacaoFirst);
            estacaoAnt.numero = 1;
        }

        public string Descricao
        {
            get { return descricao; }
            set { descricao = value; }
        }
        public int AzGraus
        {
            get { return azGraus; }
            set { azGraus = value; }
        }

        public int AzMinutos
        {
            get { return azMinutos; }
            set { azMinutos = value; }
        }

        public int AzSegundos
        {
            get { return azSegundos; }
            set { azSegundos = value; }
        }
        //Cálculo do Azimute e printar na tela
        public void LerList()
        {
            List<Angulo> azimutes = CalcularAzimutes();
            int index = 0;

            foreach (Estacao item in estacoes)
            {
                Angulo anguloEstacao = azimutes[index];
                Console.WriteLine("".PadRight(3)
                                    + item.numero
                                    + "".PadRight(16)
                                    + item.Graus
                                    + "° "
                                    + item.Minutos
                                    + "' "
                                    + item.Segundos
                                    + "'' ".PadRight(18)
                                    + item.deflexao
                                    + " ".PadRight(20)
                                    + item.distancia
                                    + "".PadRight(26)
                                    + $"{anguloEstacao.Graus}° {anguloEstacao.Minutos}' {anguloEstacao.Segundos}''");
                index++;
            }
        }

        public double Perimetro()

        {
            foreach (Estacao estacao in estacoes)
            {
                calculoPerimetro += estacao.distancia;
            }
            return calculoPerimetro;
        }

        public double getPerimetro()
        {
            calculoPerimetro = Math.Round(calculoPerimetro, 2);

            return calculoPerimetro;
            
        }

        static int LerNumeroInteiro()
        {
            int valor;
            while (!int.TryParse(Console.ReadLine(), out valor))
            {
                Console.WriteLine("Entrada inválida. Para prosseguir, insira um número:");
            }
            return valor;
        }

        static double LerNumeroDouble()
        {
            double valor;
            while (!double.TryParse(Console.ReadLine(), out valor))
            {
                Console.WriteLine("Entrada inválida. Para prosseguir, insira um número:");
            }

            return valor;
        }

        static char LerDE()
        {
            while (true)
            {
                string input = Console.ReadLine().ToUpper();
                if (input == "D" || input == "E")
                {
                    return input[0];
                }
                Console.WriteLine("Entrada inválida. Para prosseguir, insira apenas 'D' ou 'E':");
            }
        }

        public void InserirEditar(int iAcao, int numEstacao = 0, Estacao estacao = null)
        {
            Console.Clear();

            switch (iAcao)
            {
                case 0:
                    Console.WriteLine("------------------------------------------------------NOVA ESTAÇÃO------------------------------------------------------");
                    Console.WriteLine("========================================================================================================================");
                    estacao = new();
                    estacao.Numero += estacaoAnt.Numero;
                    estacaoAnt.Numero++;
                    break;

                case 1:
                    Console.WriteLine("------------------------------------------------------EDITAR ESTAÇÃO----------------------------------------------------");
                    Console.WriteLine("========================================================================================================================");
                    estacao.Numero = numEstacao;
                    break;

                default:
                    break;
            }

            Console.WriteLine("Graus:");
            estacao.Graus = LerNumeroInteiro();
                //int.Parse(Console.ReadLine());

            Console.WriteLine("Minutos:");
            estacao.Minutos = LerNumeroInteiro();  //int.Parse(Console.ReadLine());

            Console.WriteLine("Segundos");
            estacao.Segundos = LerNumeroInteiro();  //int.Parse(Console.ReadLine());

            Console.WriteLine("Distância:");
            double dis = LerNumeroDouble();   //double.Parse(Console.ReadLine());

            if (iAcao == 0) // Inserção
            {
                calculoPerimetro += dis;

            }
            else //Edição
            {   
                calculoPerimetro = (calculoPerimetro - estacao.distancia) + dis;
            }

            estacao.distancia = dis;

            Console.WriteLine("Deflexão (D, E):");
            estacao.deflexao = LerDE();  //char.Parse(Console.ReadLine());
            Console.WriteLine("========================================================================================================================");

            if (iAcao == 0)
                estacoes.Add(estacao);

            CalcularAzimutes();
        }

        public void Insercao()
        {
            InserirEditar(0);

            Console.BackgroundColor = ConsoleColor.DarkGreen;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\n--------- ESTAÇÃO Nº {estacaoAnt.numero} INSERIDA COM SUCESSO ---------\n");
            Console.ResetColor(); // Restaura as cores padrão do console
            Thread.Sleep(3000);
        }

        //Método Exclusão - Para excluir é necessário que digite o número da estação e acionará a função
        public void Exclusao()
        {
            int numero = 1;
            int estRemov = 0;
            do {
                Console.WriteLine("Excluir - Digite o Número da Estação(0 - Cancelar): ");
                numero = int.Parse(Console.ReadLine());
                

                if (numero != 1)
                {
                    foreach (Estacao e in estacoes)
                    {
                        if (e.numero == numero)
                        {
                            calculoPerimetro -= e.distancia;
                        }
                    }
                    estRemov = estacoes.RemoveAll(a => a.numero == numero);
                    int estacoesRemovidas = estRemov;

                    if (numero == 0) 
                    {
                        numero = 99991;
                        estRemov = 99991;

                    }

                    if ((estacoesRemovidas == 0) && (numero != 99991))
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("\n--------- O NÚMERO DA ESTAÇÃO É INVÁLIDA ---------\n");
                        Console.ResetColor(); // Restaura as cores padrão do console
                        Thread.Sleep(3000);

                    }  //  Console.WriteLine("O número da estação informado não existe.");
                    else if (numero != 99991)
                    {
                        Console.BackgroundColor = ConsoleColor.DarkGreen;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine($"\n--------- ESTAÇÃO Nº {numero} REMOVIDA COM SUCESSO ---------\n");
                        Console.ResetColor(); // Restaura as cores padrão do console
                        Thread.Sleep(3000);
                    }
                }
                else {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("\n--------- NÃO É PERMITIDO REMOVER A ESTAÇÃO INICIAL ---------\n");
                    Console.ResetColor();
                    Thread.Sleep(3000);
                }

            } while ((numero == 1) || (estRemov == 0));
         
        }

        public void Alteracao()
        {
            int numero = 1;
            do {

                Console.WriteLine("Alterar - Digite o Número da Estação(0 - Cancelar): ");
                numero = int.Parse(Console.ReadLine());

                if (numero == 0)
                {
                    numero = 99991;
                }

                if (numero != 1)
                {
                    bool estacaoEncontrada = false; // Inicializa como false

                    foreach (Estacao estacao in estacoes)
                    {
                        if (estacao.numero == numero)
                        {
                           Console.Clear();
                            // Editar Console....
                            InserirEditar(1, numero, estacao);
                            estacaoEncontrada = true; // Define como true se a estação for encontrada
                            Console.BackgroundColor = ConsoleColor.DarkGreen;
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.WriteLine($"\n--------- ESTAÇÃO Nº {numero} FOI ALTERADA COM SUCESSO ---------\n");
                            Console.ResetColor(); // Restaura as cores padrão do console
                            Thread.Sleep(3000);
                            break; // Você pode sair do loop, pois já encontrou a estação
                        }
                    }

                    if (!estacaoEncontrada)
                    {
                        Console.BackgroundColor = ConsoleColor.DarkRed;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("\n--------- O NÚMERO DA ESTAÇÃO É INVÁLIDA ---------\n");
                        Console.ResetColor(); // Restaura as cores padrão do console
                        Thread.Sleep(3000);

                    }
                }
                else if (numero == 1)
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("\n--------- NÃO É PERMITIDO ALTERAR A ESTAÇÃO INICIAL ---------\n");
                    Console.ResetColor();
                    Thread.Sleep(3000);
                }
            } while (numero == 1);
            
            
        }

        public void Painel()
        {
            Console.Clear();
            string data = DateTime.Now.Date.ToString("dd/MM/yyyy");
            Console.WriteLine("Engenharia Cartográfica".PadRight(45) + "Sistema de Poligonais".PadRight(57) + "Data: " + data);
            Console.WriteLine("========================================================================================================================");
            Console.WriteLine("\nPoligonal: " + descricao);
            Console.WriteLine("\n------------------------------------------------------------------------------------------------------------------------");
            Console.WriteLine("\nEstação".PadRight(20) + "Ângulo lido".PadRight(25) + "Deflexão".PadRight(20) + "Distância(m)".PadRight(30) + "Azimute".PadRight(20));
            Console.WriteLine("========================================================================================================================\n");
            LerList();
            Console.WriteLine("");
            Console.WriteLine("========================================================================================================================\n");
            Console.WriteLine("Perímetro: " + getPerimetro() + " metros" + "".PadRight(70) + "Pag.: 01 de 01");
            // Console.WriteLine("\n<Esc> Sair <F1> Inserir estação <F2> Alterar estação <F3> Excluir estação <PgDn> <PgUp>");
            string text = "\n<Esc> Sair <F1> Inserir <F2> Alterar <F3> Excluir </>CTRL+S <PgDn> <PgUp>";

            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("<Esc> Sair ");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("<F1> Inserir(+) ");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("<F2> Alterar(*) ");
            Console.ResetColor();
            
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("<F3> Excluir(-) ");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.Write("</>CTRL+S");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(" <PgDn> <PgUp>");
            Console.ResetColor();

            Console.WriteLine();
        }
        #region Atalhos 
        public void Opcoes()
        {            

            ConsoleKeyInfo keyInfo;
            bool sair = false;

            do
            {   // Verifica a tecla precionada
                keyInfo = Console.ReadKey(true);

                switch (keyInfo.Key)
                {                                 
                    case ConsoleKey.Escape: // 'ESC' para Sair
                        Console.WriteLine("Deseja fechar o sistema? (0 - Não, 1 - Sim)");
                        char opcao = Console.ReadKey().KeyChar;

                        if (opcao == '1')
                        {
                            sair = true;
                        }                        
                        break;

                    case ConsoleKey.F1: // 'F1' para Inserir                   
                        Insercao();
                        break;
                    case ConsoleKey.Add: // '+' para Inserir
                        Insercao();
                        break;
                    case ConsoleKey.F2: // 'F2' para Editar                       
                        Alteracao();
                        break;
                    case ConsoleKey.Multiply: // '*' para Editar
                        Alteracao();
                        break;
                    case ConsoleKey.F3: // 'F3' para Excluir
                        Exclusao();                        
                        break;
                    case ConsoleKey.Subtract: // '-' para Excluir
                        Exclusao();
                        break;
                    case ConsoleKey.S:
                        if ((keyInfo.Modifiers & ConsoleModifiers.Control) != 0) // 'CTRL + S'  para Salvar
                        {
                            SalvarArquivo();
                        }
                        break;
                    case ConsoleKey.Divide:
                        SalvarArquivo(); // '/' para salvar
                        break;
                    default:
                        break;
                }

                Painel();
                } while (keyInfo.Key != ConsoleKey.Escape);
            //} while (!sair);
        }
        #endregion

        #region Função responsável por calcular o Azimute
        public List<Angulo> CalcularAzimutes()
        {
            List<Angulo> azimutes = new List<Angulo>();

            // Use os valores de azAnterior para inicializar os azimutes
            int azGraus = estacaoAnt.azimute.Graus;
            int azMinutos = estacaoAnt.azimute.Minutos;
            int azSegundos = estacaoAnt.azimute.Segundos;            

            foreach (Estacao estacao in estacoes)
            {
                Angulo anguloEstacao = new Angulo();

                if (estacao.numero != 1)
                {                    

                    if (Char.ToUpper(estacao.deflexao) == 'D')
                    {
                        anguloEstacao.Segundos = azSegundos + estacao.Segundos;
                        if (anguloEstacao.Segundos > 60)
                        {
                            anguloEstacao.Minutos = 1 + azMinutos + estacao.Minutos;
                            anguloEstacao.Segundos -= 60;
                        }
                        else
                        {
                            anguloEstacao.Minutos = azMinutos + estacao.Minutos;
                        }

                        if (anguloEstacao.Minutos > 60)
                        {
                            anguloEstacao.Graus = 1 + azGraus + estacao.Graus;
                            anguloEstacao.Minutos -= 60;
                        }
                        else
                        {
                            anguloEstacao.Graus = azGraus + estacao.Graus;
                        }

                        if (anguloEstacao.Graus > 359)
                        {
                            anguloEstacao.Graus -= 360;
                        }
                    }
                    else if (Char.ToUpper(estacao.deflexao) == 'E')
                    {
                        anguloEstacao.Segundos = azSegundos - estacao.Segundos;
                        if (anguloEstacao.Segundos < 0)
                        {
                            anguloEstacao.Minutos = azMinutos + estacao.Minutos - 1;
                            anguloEstacao.Segundos += 60;
                        }
                        else
                        {
                            anguloEstacao.Minutos = azMinutos - estacao.Minutos;
                        }

                        if (anguloEstacao.Minutos < 0)
                        {
                            anguloEstacao.Graus = azGraus - estacao.Graus - 1;
                            anguloEstacao.Minutos += 60;
                        }
                        else
                        {
                            anguloEstacao.Graus = azGraus - estacao.Graus;
                        }

                        if (anguloEstacao.Graus < 0)
                        {
                            anguloEstacao.Graus += 360;
                        }
                    }

                    // Atualize os valores dos azimutes para a próxima iteração
                    azGraus = anguloEstacao.Graus;
                    azMinutos = anguloEstacao.Minutos;
                    azSegundos = anguloEstacao.Segundos;

                    // Adicione o azimute à lista de azimutes
                    azimutes.Add(anguloEstacao);
                    estacao.azimute = anguloEstacao;
                }
                else {
                    azGraus = 255;
                    azMinutos =32;
                    azSegundos = 48;

                    anguloEstacao.Graus = azGraus;
                    anguloEstacao.Minutos = azMinutos;
                    anguloEstacao.Segundos = azSegundos;

                    // Adicione o azimute à lista de azimutes
                    azimutes.Add(anguloEstacao);
                    estacao.azimute = anguloEstacao;
                }
                
                
            }

            return azimutes;
        }
        #endregion
        /*public List<Angulo> CalcularAzimutes()
        {
            List<Angulo> azimutes = new List<Angulo>();

            // Azimute inicial por padrão
            int azGraus = AzGraus;
            int azMinutos = AzMinutos;
            int azSegundos = AzSegundos;

            foreach (Estacao estacao in estacoes)
            {
                Angulo anguloEstacao = new Angulo();

                if (estacao.numero == 0)
                {
                    anguloEstacao.Graus = azGraus;
                    anguloEstacao.Minutos = azMinutos;
                    anguloEstacao.Segundos = azSegundos;
                }
                else
                {
                    if (Char.ToUpper(estacao.deflexao) == 'D')
                    {
                        anguloEstacao.Segundos = azSegundos + estacao.Segundos;
                        if (anguloEstacao.Segundos > 60)
                        {
                            anguloEstacao.Minutos = 1 + azMinutos + estacao.Minutos;
                            anguloEstacao.Segundos -= 60;
                        }
                        else
                        {
                            anguloEstacao.Minutos = azMinutos + estacao.Minutos;
                        }

                        if (anguloEstacao.Minutos > 60)
                        {
                            anguloEstacao.Graus = 1 + azGraus + estacao.Graus;
                            anguloEstacao.Minutos -= 60;
                        }
                        else
                        {
                            anguloEstacao.Graus = azGraus + estacao.Graus;
                        }

                        if (anguloEstacao.Graus > 359)
                        {
                            anguloEstacao.Graus -= 360;
                        }
                    }
                    else if (Char.ToUpper(estacao.deflexao) == 'E')
                    {
                        anguloEstacao.Segundos = azSegundos - estacao.Segundos;
                        if (anguloEstacao.Segundos < 0)
                        {
                            anguloEstacao.Minutos = azMinutos + estacao.Minutos - 1;
                            anguloEstacao.Segundos += 60;
                        }
                        else
                        {
                            anguloEstacao.Minutos = azMinutos - estacao.Minutos;
                        }

                        if (anguloEstacao.Minutos < 0)
                        {
                            anguloEstacao.Graus = azGraus - estacao.Graus - 1;
                            anguloEstacao.Minutos += 60;
                        }
                        else
                        {
                            anguloEstacao.Graus = azGraus - estacao.Graus;
                        }

                        if (anguloEstacao.Graus < 0)
                        {
                            anguloEstacao.Graus += 360;
                        }
                    }
                }

                // Atualize os valores dos azimutes
                azGraus = anguloEstacao.Graus;
                azMinutos = anguloEstacao.Minutos;
                azSegundos = anguloEstacao.Segundos;

                // Adicione o azimute à lista de azimutes
                azimutes.Add(anguloEstacao);
            }

            return azimutes;
        }
        */

        #region Funções responsáveis por gerar o arquivo de texto
        public void SalvarArquivo()
        {
            Console.WriteLine("\nDigite o nome do arquivo para salvar:");
            string nomeArquivo = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(nomeArquivo))
            {
                nomeArquivo = "arquivo.txt";
            }

            if (!nomeArquivo.EndsWith(".txt"))
            {
                nomeArquivo += ".txt";
            }

            Console.WriteLine($"\nSalvando {nomeArquivo}...");

            //Cria o arquivo
            using (StreamWriter arquivo = new StreamWriter(nomeArquivo))
            {   // Define um Layout para o arquivo 
                string linhaSeparadora = new string('-', 70);
                arquivo.WriteLine(linhaSeparadora);
                arquivo.WriteLine("| Estação | Ângulo       | Deflexão | Distância | Azimute        |");
                arquivo.WriteLine("|---------|--------------|-----------|-----------|---------------|");

                //Percorre a lista de Estações inserindo no arquivo
                foreach (Estacao estacao in estacoes)
                {
                    string linha = $"| {estacao.numero,-7} | {FormatarAngulo(estacao.Graus, estacao.Minutos, estacao.Segundos)} | {estacao.deflexao,-8} | {estacao.distancia,-9} | {FormatarAngulo(estacao.azimute.Graus, estacao.azimute.Minutos, estacao.azimute.Segundos)} |";
                    // Grava a linha
                    arquivo.WriteLine(linha);
                }
                // Salva o arquivo 
                arquivo.WriteLine(linhaSeparadora);
            }

            Console.WriteLine($"Os dados foram salvos com sucesso no arquivo: {nomeArquivo}");
            Thread.Sleep(3000);
            Console.Clear();
        }

        private string FormatarAngulo(int graus, int minutos, int segundos)
        {   // Formata os Angulos para exibição no arquivo
            return $"{graus,3}° {minutos,2}' {segundos,2}''";
        }

        #endregion


    }

}
